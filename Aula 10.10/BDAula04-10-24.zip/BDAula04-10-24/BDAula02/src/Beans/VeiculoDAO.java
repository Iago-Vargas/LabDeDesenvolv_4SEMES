/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Beans;


import Beans.Pessoa;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import Conexao.Conexao;
import Conexao.Conexao;
import java.sql.PreparedStatement;

/**
 *
 * @author laboratorio
 */
public class VeiculoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public VeiculoDAO(){
        this.conexao = new Conexao();
        this.conn = (Connection) this.conexao.getConexao();
    }
    
    public void inserir(Veiculo veiculo){
        String sql = "INSERT INTO veiculo (modelo, placa, id_pessoa) VALUES (?,?,?);";
       
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, veiculo.getModelo());
        stmt.setString(2, veiculo.getPlaca());
        stmt.setInt(3, veiculo.getPessoaid().getId());

        stmt.execute();
    } catch (SQLException ex) {
        System.out.println("Erro ao inserir Veiculo: " + ex.getMessage());
    }
}
    public Veiculo consultar(int id) {
    Veiculo veiculo = null;
    String sql = "SELECT v.modelo, v.placa, p.nome FROM veiculo v INNER JOIN pessoa p ON v.id_pessoa = p.id WHERE v.id = ?";

    try {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        java.sql.ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            veiculo = new Veiculo();
            veiculo.setId(id);
            veiculo.setModelo(rs.getString("modelo"));
            veiculo.setPlaca(rs.getString("placa"));

            Pessoa pessoa = new Pessoa(); // Supondo que você tenha uma classe Pessoa
            pessoa.setNome(rs.getString("nome")); // Método para definir o nome
            veiculo.setPessoaid(pessoa);
        }
    } catch (SQLException ex) {
        System.out.println("Erro ao consultar veículo: " + ex.getMessage());
    }

    return veiculo;
}

    public void editar(Veiculo veiculo) {
    try {
        String sql = "UPDATE veiculo set modelo=?, placa=?, id_pessoa=? WHERE id=?";

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, veiculo.getModelo());
        stmt.setString(2, veiculo.getPlaca());
        stmt.setInt(3, veiculo.getPessoaid().getId());
        stmt.setInt(4, veiculo.getId());

        stmt.execute();
    } catch (SQLException ex) {
        System.out.println("Erro ao atualizar Veiculo: " + ex.getMessage());
    }
}

    public void excluir(int id) {
    try {
        String sql = "delete from veiculo WHERE id=?";

        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);

        stmt.execute();
    } catch (SQLException ex) {
        System.out.println("Erro ao excluir veiculo: " + ex.getMessage());
    }
}
    }

